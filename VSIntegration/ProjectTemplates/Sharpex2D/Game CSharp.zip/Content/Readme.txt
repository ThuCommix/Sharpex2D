﻿Place your content in this folder or create a new one and reconfigure the content pipeline path. 
To do so, adjust the paths in the content.proj file