﻿using System;
using Sharpex2D.Framework;
using Sharpex2D.Framework.Audio.OpenAL;
using Sharpex2D.Framework.Rendering;
using Sharpex2D.Framework.Rendering.OpenGL;

namespace $safeprojectname$
{
    public class Game1 : Game
    {
        /// <summary>
        /// Setup the game
        /// </summary>
        /// <param name="launchParameters">The launch parameters</param>
        public override void Setup(LaunchParameters launchParameters)
        {
            //Initialize your game settings

            GraphicsManager = new OpenGLGraphicsManager
            {
                //Resolution settings
                PreferredBackBufferWidth = 800,
                PreferredBackBufferHeight = 480
            };

            //The root content folder
            Content.RootPath = "Content";

            //The sound manager
            SoundManager = new ALSoundManager();
        }

        /// <summary>
        /// Initializes the game
        /// </summary>
        public override void Initialize()
        {
            //Set your window title
            Window.Title = "My first Sharpex2D game";

            //Disallow the resizing of the window
            Window.AllowUserResizing = false;
        }

        /// <summary>
        /// Updates the game
        /// </summary>
        /// <param name="gameTime">The game time</param>
        public override void Update(GameTime gameTime)
        {
            //Code your update logic here
        }

        /// <summary>
        /// Draws the game
        /// </summary>
        /// <param name="spriteBatch">The spritebatch</param>
        /// <param name="gameTime">The game time</param>
        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            spriteBatch.Begin(SpriteSortMode.Deferred);

            //Draw your game here

            spriteBatch.End();
        }

        /// <summary>
        /// Loads the content
        /// </summary>
        public override void LoadContent()
        {
            //Load your content here
            //var texture = Content.Load<Texture2D>("path");
        }

        /// <summary>
        /// Main entry point of your game
        /// </summary>
        [STAThread]
        static void Main()
        {
            var game = new Game1();
            game.Run();
        }
    }
}
