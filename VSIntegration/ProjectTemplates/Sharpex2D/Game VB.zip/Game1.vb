﻿Imports Sharpex2D.Framework
Imports Sharpex2D.Framework.Audio.OpenAL
Imports Sharpex2D.Framework.Rendering
Imports Sharpex2D.Framework.Rendering.OpenGL

Public Class Game1
    Inherits Game

    ''' <summary>
    ''' Setup the game
    ''' </summary>
    ''' <param name="launchParameters">The launch parameters</param>
    Public Overrides Sub Setup(launchParameters As LaunchParameters)
        'Initialize your game settings

        GraphicsManager = New GLGraphicsManager()

        'Resolution settings
        GraphicsManager.PreferredBackBufferWidth = 800
        GraphicsManager.PreferredBackBufferHeight = 480

        'The root content folder
        Content.RootPath = "Content"

        'The sound manager
        SoundManager = New ALSoundManager()
    End Sub

    ''' <summary>
    ''' Initializes the game
    ''' </summary>
    Public Overrides Sub Initialize()
        'Set your window title
        Window.Title = "My first Sharpex2D game"

        'Disallow the resizing of the window
        Window.AllowUserResizing = False
    End Sub

    ''' <summary>
    ''' Updates the game
    ''' </summary>
    ''' <param name="gameTime">The game time</param>
    Public Overrides Sub Update(gameTime As GameTime)
        'Code your update logic here
    End Sub

    ''' <summary>
    ''' Draws the game
    ''' </summary>
    ''' <param name="spriteBatch">The spritebatch</param>
    ''' <param name="gameTime">The game time</param>
    Public Overrides Sub Draw(spriteBatch As SpriteBatch, gameTime As GameTime)
        spriteBatch.Begin(SpriteSortMode.Deferred)

        'Draw your game here

        spriteBatch.End()
    End Sub

    ''' <summary>
    ''' Loads the content
    ''' </summary>
    Public Overrides Sub LoadContent()
        'Load your content here
        'Content.Load(Of Texture2D)("path")
    End Sub

    ''' <summary>
    ''' Main entry point of your game
    ''' </summary>
    Shared Sub Main()
        Dim game As New Game1()
        game.Run()
    End Sub
End Class
