﻿using Sharpex2D;
using Sharpex2D.GameService;
using Sharpex2D.Surface;

namespace $safeprojectname$
{
    public class MainGame : Game
    {

        public override void OnRendering(Rendering.RenderDevice renderer, GameTime gameTime)
        {
            renderer.Begin();

            //add your draw logic here.

            renderer.End();
        }

        public override void OnUpdate(GameTime gameTime)
        {
            //add your update logic here
        }

        public override EngineConfiguration OnInitialize(LaunchParameters launchParameters)
        {
            //setup your window
            GameWindow window = SGL.QueryComponents<RenderTarget>().Window;
            window.Title = "Sharpex2D Game";
            //initialize your game here
            return new EngineConfiguration(new Sharpex2D.Rendering.GDI.GDIRenderDevice(),
               new Audio.WaveOut.WaveOutInitializer());
        }

        public override void OnLoadContent()
        {
            //Load your content here.
        }
    }
}
